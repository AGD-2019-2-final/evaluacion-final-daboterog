
Pregunta
===========================================================================

Escriba un job de hadoop (en Python) que compute la suma y el promedio de 
la tercera columna por letra del  archivo `data.csv`.  
