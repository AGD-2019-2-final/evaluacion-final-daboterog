
Pregunta
===========================================================================

Escriba un job de hadoop (en Python) que compute la cantidad de registros
por mes para el archivo `data.csv`.
