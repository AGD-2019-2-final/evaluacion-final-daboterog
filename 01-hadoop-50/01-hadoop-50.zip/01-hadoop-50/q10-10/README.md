Pregunta
===========================================================================

Escriba un job de hadoop (en Python) que obtenga las letras asociadas 
(columna 2) a cada clave (columna 1) del  archivo `data.csv`.  
