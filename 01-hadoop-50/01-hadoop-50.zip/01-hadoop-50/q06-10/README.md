Pregunta
===========================================================================

Escriba un job de hadoop (en Python) que compute los valores máximo y 
mínimo de la tercera columna por letra, para el archivo `data.csv`.
