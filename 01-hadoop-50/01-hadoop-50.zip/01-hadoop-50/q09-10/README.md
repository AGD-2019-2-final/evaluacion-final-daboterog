Pregunta
===========================================================================

Escriba un job de hadoop (en Python) que obtenga los 5 registros con 
valores más pequeños en la tercera columna del  archivo `data.csv`.  
